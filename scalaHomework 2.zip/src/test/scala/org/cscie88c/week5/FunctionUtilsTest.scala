package org.cscie88c.week5

import org.cscie88c.testutils.{ StandardTest }
import FunctionUtils.CustomerTransaction

// run using: sbt "testOnly org.cscie88c.week5.FunctionUtilsTest"
class FunctionUtilsTest extends StandardTest {
  "FunctionUtils" when {
    // Problem 1 unit tests
    "calling colorToCode" should {
      "return the correct value for white" in {
        // write unit tests here
      }
    }

    "calling fizzBuzzString" should {
      "return the correct value" in {
        // write unit tests here
      }
    }

    "calling fizzBuzz" should {
      "return the correct value" in {
        // write unit tests here
      }
    }
    
    // Problem 2 unit tests

    // Problem 3 unit tests

    // Bonus unit tests
  }

}
