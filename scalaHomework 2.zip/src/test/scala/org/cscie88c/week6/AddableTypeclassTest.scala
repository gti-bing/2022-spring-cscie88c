package org.cscie88c.week6

import org.cscie88c.testutils.{ StandardTest }

class AddableTypeclassTest extends StandardTest {
  
  "AddableAggregator" should {
    "sum a list of integers" in {
      // add your unit tests here
    }
    "sum a list of booleans" in {
      // add your unit tests here
    }
    "sum a list of employees" in {
      // add your unit tests here
    }
  }
}
