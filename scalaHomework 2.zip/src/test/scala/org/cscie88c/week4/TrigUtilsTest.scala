package org.cscie88c.week4

import org.cscie88c.testutils.{StandardTest}

class TrigUtilsTest extends StandardTest {
  
  "TrigUtils" when {
    "calling sin" should {
      "return the correct value for 90" in {
        // write unit test below
      }
    
    }

    // write tests for cos and squared below
  }
}
