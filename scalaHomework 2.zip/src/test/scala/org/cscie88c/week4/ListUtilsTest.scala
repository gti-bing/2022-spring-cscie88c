package org.cscie88c.week4

import org.cscie88c.testutils.{StandardTest}

class ListUtilsTest extends StandardTest {
  "ListUtils" when {
    "calling ones" should {
      "return the correct value" in {
        // write unit test here
      }
    
    }

    // write unit tests for zeroes, and other functions here
  }

}
