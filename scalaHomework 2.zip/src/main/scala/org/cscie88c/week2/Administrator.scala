package org.cscie88c.week2

// write code for class Administrator below
