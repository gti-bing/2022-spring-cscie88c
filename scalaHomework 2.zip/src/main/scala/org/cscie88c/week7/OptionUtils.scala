package org.cscie88c.week7

import scala.io.Source
import scala.util.{ Failure, Success, Try }

object OptionUtils {

  def fileCharCount(fileName: String): Try[Long] = ???

  def charCountAsString(fileName: String): String = ???

  def lineStreamFromFile(fileName: String): Option[LazyList[String]] = ???
}
