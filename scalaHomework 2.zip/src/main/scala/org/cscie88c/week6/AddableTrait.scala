package org.cscie88c.week6

// define the trait AddableTrait with parameterized type A below

// define the case class MyInt that implements AddableTrait for MyInt type below

// define the case class MyBool that implements AddableTrait for MyBool type below
